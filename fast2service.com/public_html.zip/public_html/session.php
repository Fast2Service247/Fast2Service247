<?php 
include('config.php');
session_start();
include('config.php');
$qry="select * from wallet ";
$res=mysqli_query($conn, $qry);
while($row=mysqli_fetch_array($res))
{
    $id=$row['id'];
    $wallet_amount=$row['wallet_amount'];
    
}

include('session.php');
$email=$_SESSION['$u_mobile_number'];
include('config.php');
$qry="select * from user where u_email='".$u_mobile_number."'";
                    $res=mysqli_query($conn, $qry);
                     while($row=mysqli_fetch_array($res))
                     {
                             
                                $u_name=$row["u_name"];
                                $u_email=$row['u_email'];
                                $u_mobile_number=$row['u_mobile_number'];
                                $u_image=$row['u_image'];
					 }
 
 
   
?> 