<?php
$servername = "localhost";
$database = "u546040841_fast2service";
$username = "u546040841_fast_service";
$password = "Fast@123";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
// if (!$conn) {
//     die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully";
// mysqli_close($conn);
?>