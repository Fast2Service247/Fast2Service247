<style>
    .bar-icon span{background: #cd2121;}
    .navbar-brand.logo-small img{margin-left: -125px;}
    .cate{display: none!important;}
    @media only screen and (max-width: 600px) {
        .cate{display: block!important;}
        .cate2{display: none!important;}
     }
</style>