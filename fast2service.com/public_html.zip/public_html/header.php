<header class="header">
<nav class="navbar navbar-expand-lg header-nav">
				<div class="navbar-header">
					<a id="mobile_btn" href="javascript:void(0);">
						<span class="bar-icon">
							<span></span>
							<span></span>
							<span></span>
						</span>
					</a>
					<a href="index.php" class="navbar-brand logo">
						<img src="assets/img/logo.png" class="img-fluid" alt="Logo">
					</a>
					<a href="index.php" class="navbar-brand logo-small">
						<img src="assets/img/logo.png" class="img-fluid" alt="Logo">
					</a>
				</div>
				<div class="main-menu-wrapper">
					<!--<div class="menu-header">-->
					<!--	<a href="index.php" class="menu-logo">-->
					<!--		<img src="assets/img/logo.png" class="img-fluid" alt="Logo">-->
					<!--	</a>-->
					<!--	<a id="menu_close" class="menu-close" href="javascript:void(0);"> <i class="fas fa-times"></i></a>-->
					<!--</div>-->
					<ul class="main-nav">
						<li>
							<a href="index.php">Home</a>
						</li>
						<!--<li class="active">-->
						<!--	<a href="categories.php">Categories</a>-->
						<!--</li>-->

						
						<li class="has-submenu">
							<a href="#">Service <i class="fas fa-chevron-down"></i></a>
							<ul class="submenu">
								<li><a href="cleaning_categories.php">Cleaning</a></li>
								<li><a href="soloon_categories.php">Men/Women soloon</a></li>
								<li><a href="Car_wash.php">Car wash</a></li>
								<li><a href="Electrician.php">Electrician</a></li>
								
							</ul>
						</li>
					<li class="menu1"><a href="term_condition.php">Terms & Conditions</a></li>
					<li class="menu1"><a href="privacy_policy.php">Porvicy Policy</a></li>
					<li class="menu2"><a href="#">Blog</a></li>
					<li class="menu1"><a href="#">Review</a></li>
					<li class="menu1"><a href="#">Near Me</a></li>
					<li class="menu1"><a href="#">Gift Card</a></li>
					<li class="menu1"><a href="about_us.php">About Us</a></li>
					<li class="menu1"><a href="contact_us">Contect Us</a></li>
					<!--<li><a href="javascript:void(0);" data-toggle="modal" data-target="#login_modal_provider"> Provider</a></li>-->
					<!--<li><a href="javascript:void(0);" data-toggle="modal" data-target="#login_modal">User</a></li>-->

					</ul>
				</div>

				<ul class="nav header-navbar-rht">
					<li class="nav-item">
						<a class="nav-link header-login" href="javascript:void(0);" data-toggle="modal" data-target="#login">Login</a>
					</li>
				</ul>
			</nav>
				<div class="wrap">
   <div class="search">
      <input type="text" class="searchTerm" placeholder="What are you looking for?">
      <button type="submit" class="searchButton">
        <i class="fa fa-search"></i>
     </button>
   </div>
</div>
		</header>
		<div class="lodive1 loc">
		    <siv class="lodive2">
		         <i class="fas fa-map-marker-alt ml-1"></i> <span id="live"></span>
		    </siv>
		</div>
	