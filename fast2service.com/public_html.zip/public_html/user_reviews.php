 <?php include('session.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Fast2Service</title>

	<!-- Favicons -->
	
	
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,500;0,600;0,700;1,400&display=swap" rel="stylesheet"> 
	
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<?php include ('user_style.php'); ?>
<?php include ('style.php'); ?>
<body>

	<div class="main-wrapper">
	
		<!-- Header -->
		<?php include ('header1.php'); ?>
		<!-- /Header -->
		
		<div class="content">
			<div class="container">
				<div class="row">
					<div class="col-xl-3 col-md-4">
						<div class="mb-4">
							<div class="d-sm-flex flex-row flex-wrap text-center text-sm-left align-items-center">
								<img alt="profile image" src="assets/upload_img/<?php echo $u_image; ?>" class="avatar-lg rounded-circle">
								<div class="ml-sm-3 ml-md-0 ml-lg-3 mt-2 mt-sm-0 mt-md-2 mt-lg-0">
									<h6 class="mb-0"><?php echo $u_name; ?></h6>
									<!--<p class="text-muted mb-0">Member Since Apr 2020</p>-->
								</div>
							</div>
						</div>
						<div class="widget settings-menu">
							<ul role="tablist" class="nav nav-tabs">
								<li class="nav-item current">
									<a href="user-dashboard.php" class="nav-link">
										<i class="fas fa-chart-line"></i> <span>Dashboard</span>
									</a>
								</li>
								<li class="nav-item current">
									<a href="user-bookings.php" class="nav-link">
										<i class="far fa-calendar-check"></i> <span>My Bookings</span>
									</a>
								</li>
								<li class="nav-item">
									<a href="user-settings.php" class="nav-link">
										<i class="far fa-user"></i> <span>Profile Settings</span>
									</a>
								</li>
								<li class="nav-item">
									<a href="user-wallet.php" class="nav-link">
										<i class="far fa-money-bill-alt"></i> <span>Wallet</span>
									</a>
								</li>
								<li class="nav-item">
									<a href="user-reviews.php" class="nav-link active">
										<i class="far fa-star"></i> <span>Reviews</span>
									</a>
								</li>
								<li class="nav-item">
									<a href="user-payment.php" class="nav-link">
										<i class="fas fa-hashtag"></i> <span>Payment</span>
									</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-xl-9 col-md-8">
						<h4 class="widget-title">Reviews</h4>
						<div class="card review-card mb-0">
							<div class="card-body">
								<div class="review-list">
									<div class="review-img">
										<img class="rounded img-fluid" src="assets/img/services/service-12.jpg" alt="">
									</div>
									<div class="review-info">
										<h5><a href="">Air Conditioner Service</a></h5>
										<div class="review-date">July 11, 2020 11:38 am</div>
										<p class="mb-2">Good Work</p>
										<div class="review-user">
											<img class="avatar-xs rounded-circle" src="assets/img/provider/provider-01.jpg" alt=""> Thomas Herzberg
										</div>
									</div>
									<div class="review-count">
										<div class="rating">
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<span class="d-inline-block average-rating">(5)</span>
										</div>
									</div>
								</div>
								<div class="review-list">
									<div class="review-img">
										<img class="rounded img-fluid" src="assets/img/services/service-11.jpg" alt="">
									</div>
									<div class="review-info">
										<h5><a href="">Wooden Carpentry Work</a></h5>
										<div class="review-date">July 05, 2020 15:33 pm</div>
										<p class="mb-2">Best Work</p>
										<div class="review-user">
											<img class="avatar-xs rounded-circle" src="assets/img/provider/provider-02.jpg" alt=""> Matthew Garcia
										</div>
									</div>
									<div class="review-count">
										<div class="rating">
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<span class="d-inline-block average-rating">(5)</span>
										</div>
									</div>
								</div>
								<div class="review-list">
									<div class="review-img">
										<img class="rounded img-fluid" src="assets/img/services/service-10.jpg" alt="">
									</div>
									<div class="review-info">
										<h5><a href="">Plumbing Services</a></h5>
										<div class="review-date">June 29, 2020 05:04 am</div>
										<p class="mb-2">Excellent Service</p>
										<div class="review-user">
											<img class="avatar-xs rounded-circle" src="assets/img/provider/provider-03.jpg" alt=""> Yolanda Potter
										</div>
									</div>
									<div class="review-count">
										<div class="rating">
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star"></i>
											<span class="d-inline-block average-rating">(4)</span>
										</div>
									</div>
								</div>
								<div class="review-list">
									<div class="review-img">
										<img class="rounded img-fluid" src="assets/img/services/service-09.jpg" alt="">
									</div>
									<div class="review-info">
										<h5><a href="">Commercial Painting Services</a></h5>
										<div class="review-date">June 26, 2020 02:22 am</div>
										<p class="mb-2">Thanks</p>
										<div class="review-user">
											<img class="avatar-xs rounded-circle" src="assets/img/provider/provider-04.jpg" alt=""> Ricardo Flemings
										</div>
									</div>
									<div class="review-count">
										<div class="rating">
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<span class="d-inline-block average-rating">(5)</span>
										</div>
									</div>
								</div>
								<div class="review-list">
									<div class="review-img">
										<img class="rounded img-fluid" src="assets/img/services/service-08.jpg" alt="">
									</div>
									<div class="review-info">
										<h5><a href="">Building Construction Services</a></h5>
										<div class="review-date">June 13, 2020 17:38 pm</div>
										<p class="mb-2">Amazing</p>
										<div class="review-user">
											<img class="avatar-xs rounded-circle" src="assets/img/provider/provider-05.jpg" alt=""> Maritza Wasson
										</div>
									</div>
									<div class="review-count">
										<div class="rating">
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star"></i>
											<span class="d-inline-block average-rating">(4)</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Footer -->
		<?php include ('footer.php'); ?>
	
</body>
</html>