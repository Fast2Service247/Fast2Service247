 <style>
 .abcRioButton{width: 100%!important;}
	.bar-icon span{background: #cd2121;}
	.search2 {margin-left: 8px;width: 85%;border: none;margin-top: 6px;}
	
	.colsize{padding: 4%;}
	#otpdiv{

		display: none;
	}
	#verifyotp{

		display: none;
	}
	#resend_otp{
		display: none;
	}

	.countdown{
		display: table;
		width: 100%;
		text-align: left;
		font-size: 15px;

	}

	#resend_otp:hover{

		text-decoration:underline;
		

	}
	.heading2 {padding: 5px 0 5px 0px;
    margin-bottom: 20px;}
    
    .search {
  width: 100%;
  position: relative;
  display: flex;
}

.searchTerm {
  width: 100%;
  border: 3px solid #ff0080;
  border-right: none;
  padding: 5px;
  height: 39px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #9DBFAF;
}

.searchTerm:focus{
  color: #00B4CC;
}
.font6{    border: 2px solid #ffbe4a;
    border-radius: 50%;
    height: 39px;
    width: 39px;
    padding-top: 7px;
    font-size: 16px;
    color: #e9ecef;
    background-color: #cd2121;
    margin-top: -1px;
}

.searchButton {
  width: 40px;
  height: 39px;
  border: 1px solid #ff0080;;
  background: #ff0080;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 20px;
}

/*Resize the wrap to see the search bar change!*/
.wrap{
     width: 99%;
    /* position: absolute; */
    /* top: 50%; */
    /* left: 54%; */
    /* transform: translate(-50%, -50%); */
    margin-top: -10px;
    padding: 0px 10px 0px 10px;
    margin-bottom: 5px;
}
.wrap{display: none!important;}
.loc{display: none!important;}
.header-navbar-rht li > a.header-login {margin-right: 4px!important;}
.category-section {padding: 0px 0!important; position: unset;padding-top: 55px!important;}
.lodive1{position: absolute;margin-top: 24px;background-color: #0000002b;width: 100%;height: 30px;}
.lodive2{margin-left: 6px;padding-top: 6px;position: absolute;}
.phofooter{display: none!important;}
.serv-img{height: 310px!important; border-radius:0px!important;}
.service-img {border-radius: 4px 4px 0 0!important;}
.service-widget {border-radius: 4px!important;}
.service-content {padding: 3px!important;}
.service-price {color: #ff0080;}
.service-content .title {margin-bottom: 0px;}
.location{font-size: 12px;margin-left: -18px;}
.item-info {position: absolute;/* left: 0; */bottom: 0;/* width: 100%; */padding: 5px 5px 0px 0px;z-index: 1;right: 0px;top: 0px;}
.menu1{display: none!important;}
.service-widget .rating{margin-bottom: 0px!important;}
.rating {margin: 4 0 0px!important;}
.service-img::before{background:none}
.phone{display: none!important;}
.pc{display: block!important;}
.service-tabs li{margin-left: 5px!important;}

       @media only screen and (max-width: 600px) {
        .he_banner{display: none!important;}
        .wrap{display: block!important;}
        .loc{display: block!important;}
        .how-work{display: none!important;}
        .in_footer{display: none!important;}
        .phofooter{display: block!important;}
        .header-nav {margin-top: -10px;}
        .footer{background-color: white;height: 53px;width: 100%;box-shadow: 0px 0px 10px rgb(0 0 0 / 30%);bottom: 0;position: fixed;z-index: 1000;}
        .fooicon{margin: 7px 0px 0px 25px;text-align: center;}
        .serv-img{height: 123px!important; border-radius:0px!important;}
        .cate-list a {padding: 2px 7px!important;font-size: 11px!important;}
        .breadcrumb-bar .breadcrumb-title{margin-top: 61px;}
        .menu1{display: block!important;}
        .phone{display: block!important;}
        .pc{display: none!important;}
       }
       </style>