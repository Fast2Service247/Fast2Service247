<style>
    .bar-icon span{background: #cd2121;}
    .navbar-brand.logo-small img{margin-left: -125px;}
    .cate3{display: none!important;}
    .sidebar-overlay{z-index: 109!important}
    @media only screen and (max-width: 600px) {
        .cate3{display: block!important;}
        .cate4{display: none!important;}
     }
</style>