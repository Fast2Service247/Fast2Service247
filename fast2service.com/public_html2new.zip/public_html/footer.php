	<footer class="footer phofooter">
		<div class="container">
		<div class="row">
	
		    <div class="fooicon"><i class="fas fa-home" style="font-size: 22px;"></i><h6>Home</h6></div>
		    <div class="fooicon"><i class="fas fa-address-book" style="font-size: 22px;"></i><h6>Booking</h6></div>
		    <div class="fooicon"><h6 class="font6"><b>F<span>2</span>S</b></h6></div>
		    <div class="fooicon"><i class="fas fa-gift" style="font-size: 22px;"></i><h6>Rewards</h6></div>
		    <div class="fooicon"><i class="fas fa-user-alt" style="font-size: 22px;"></i><h6>Profile</h6></div>
	
		 </div>
		 </div>
		</footer>
		<!-- Footer -->
		<footer class="footer in_footer">
		
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6">
							<!-- Footer Widget -->
							<div class="footer-widget footer-menu">
								<h2 class="footer-title">Quick link</h2>
								<ul>
									<bv></bv><li>
										<a href="search.html">About Us
										</a>
									</li>
									<li>
										<a href="search.html">Terms & Conditions </a>
									</li>
									<li>
										<a href="search.html">Porvicy Policy</a>
									</li>
									<li>
										<a href="search.html">Blog</a>
									</li>
									<li>
										<a href="search.html">Review</a>
									</li>
									<li>
										<a href="search.html">Near Me</a>
									</li>
									<li>
										<a href="search.html">Gift Card</a>
									</li>
									<li>
										<a href="search.html">Contect Us</a>
									</li>
									</bv>
								</ul>
							</div>
							<!-- /Footer Widget -->
						</div>
						<div class="col-lg-3 col-md-6">
							<!-- Footer Widget -->
							<div class="footer-widget footer-menu">
								<h2 class="footer-title">Serving In</h2>
								<ul>
									<li>
										<a href="">Udaipur</a>
									</li>
									<li>
										<a href=""></a>
									</li>
									<li>
										<a href=""></a>
									</li>
									<li>
										<a href=""></a>
									</li>
								</ul>
							</div>
							<!-- /Footer Widget -->
						</div>
						<div class="col-lg-3 col-md-6">
							<!-- Footer Widget -->
							<div class="footer-widget footer-contact">
								<h2 class="footer-title">Contact Us</h2>
								<div class="footer-contact-info">
									<div class="footer-address">
										<span><i class="far fa-building"></i></span>
										<p>Near shiv mandir Pratapnagar Udaipur Rajsthan - 313001</p>
									</div>
									<p><i class="fas fa-headphones"></i> 8890260549</p>
									<p class="mb-0"><i class="fas fa-envelope"></i> info@fast2service.com

</p>
								</div>
							</div>
							<!-- /Footer Widget -->
						</div>
						<div class="col-lg-3 col-md-6">
							<!-- Footer Widget -->
							<div class="footer-widget">
								<h2 class="footer-title">Follow Us</h2>
								<div class="social-icon">
									<ul>
										<li>
											<a href="https://www.facebook.com/fast2service" target="_blank"><i class="fab fa-facebook-f"></i> </a>
										</li>
										<li>
											<a href="https://twitter.com/Fast2Service" target="_blank"><i class="fab fa-twitter"></i> </a>
										</li>
										<li>
											<a href="https://www.youtube.com/channel/UCQlerlaFEySb6MruFzN6iKA" target="_blank"><i class="fab fa-youtube"></i></a>
										</li>
										<li>
											<a href="https://www.instagram.com/fast2service" target="_blank"><i class="fab fa-instagram"></i></a>
										</li>
									</ul>
								</div>
								<form action="mail.php" method="post">
								<div class="subscribe-form">
                                    <input type="email" class="form-control" placeholder="Enter your email" name="email" required>
                                    <button type="submit" class="btn footer-btn" name="submit">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                                </form>
							</div>
							<!-- /Footer Widget -->
						</div>
					</div>
				</div>
			</div>
			<!-- /Footer Top -->
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="container">
					<!-- Copyright -->
					<div class="copyright">
						<div class="row">
							<div class="col-md-4 col-lg-4">
								<div class="copyright-text">
									<p class="mb-0">&copy; 2021 <a href="">Fast2Service</a>. All rights reserved.</p>
								</div>
							</div>
							<div class="col-md-4 col-lg-4">
								<a href="javascript:void(0);" data-toggle="modal" data-target="#provider-register" id="bec">Become a Professional</a> |
								<a href="javascript:void(0);" data-toggle="modal" data-target="#user-register" id="bec">Become a User</a>
							</div>

							<div class="col-md-4 col-lg-4">
								<!-- Copyright Menu -->
								<div class="copyright-menu">
									<ul class="policy-menu">
										<li>
											<a href="term_condition.php">Terms and Conditions</a>
										</li>
										<li>
											<a href="privacy_policy.php">Privacy</a>
										</li>
									</ul>
								</div>
								<!-- /Copyright Menu -->
							</div>
						</div>
					</div>
					<!-- /Copyright -->
				</div>
			</div>
			<!-- /Footer Bottom -->
			
		</footer>
		<!-- /Footer -->
		
	</div>
	
	
	<script>
         $(".carousel").owlCarousel({
           margin: 20,
           loop: true,
           autoplay: false,
           autoplayTimeout: 2000,
           autoplayHoverPause: true,
           responsive: {
             0:{
               items:1,
               nav: false
             },
             600:{
               items:2,
               nav: false
             },
             1000:{
               items:3,
               nav: false
             }
           }
         });
         </script>
         
         <script>
        //  $(".carousela").owlCarousel({
        //   margin: 20,
        //   loop: true,
        //   autoplay: false,
        //   autoplayTimeout: 5000,
        //   autoplayHoverPause: true,
        //   responsive: {
        //      0:{
        //       items:2,
        //       nav: false
        //      },
        //      600:{
        //       items:2,
        //       nav: false
        //      },
        //      1000:{
        //       items:3,
        //       nav: false
        //      }
        //   }
        //  });
         
        $('.carousela').owlCarousel({
    center: true,
    items:2,
    loop:true,
    margin:10,
    responsive:{
        600:{
            items:4
        }
    }
});
      </script>
	
<script>	
	
	window.onload = function cmb(){
if (navigator.geolocation) 
{
   navigator.geolocation.getCurrentPosition(mc);
}
else
{
   alert("your browser does not support geolocation api");
}
} 

function mc(position){
var myapi="https://api.opencagedata.com/geocode/v1/json?q="+position.coords.latitude+","+position.coords.longitude+"&key=87f70e732bbd44d984f351fc57d3e4cc";


$.get(myapi,function(data){
console.log(data);
$("#live").text(data.results[0].components.county);
});
}
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	
	 
	 
	<?php include('form.php'); ?>
<script>
                
                function logout(){
                    var auth2 = gapi.auth2.getAuthInstance();
                    auth2.signOut();  
                    jQuery.ajax({
                                url:'logout.php',
                                success:function(result){
                                        window.location.href="index.php";
                                }
                        });
                    
                }
                
                function onLoad(){
                      gapi.load('auth2',function (){
                              gapi.auth2.init();
                      }); 
                }
                
                function gmailLogIn(userInfo){
                        var userProfile=userInfo.getBasicProfile();
                        
                        
                        jQuery.ajax({
                                url:'login_check.php',
                                type:'post',
                                data:'user_id='+userProfile.getId()+'&name='+userProfile.getName()+'&image='+userProfile.getImageUrl()+'&email='+userProfile.getEmail(),
                                success:function(result){
                                        window.location.href="user_index.php";
                                }
                        });
                }
                </script>
                 <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

<!-- jQuery -->
	<script src="assets/js/jquery-3.5.0.min.js"></script>

	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

	<!-- Owl JS -->
	<script src="assets/plugins/owlcarousel/owl.carousel.min.js"></script>

	<!-- Custom JS -->
	<script src="assets/js/script.js"></script>